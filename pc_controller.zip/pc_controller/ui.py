from __future__ import annotations

import logging
import sys
from os import startfile
from pathlib import Path

from PySide6.QtCore import QEasingCurve, Property, QPropertyAnimation, Qt, QTimer
from PySide6.QtGui import QAction, QColor
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QFormLayout,
    QFrame,
    QGraphicsDropShadowEffect,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QStyle,
    QSystemTrayIcon,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from . import autostart
from .bot_service import HELP_TEXT, TelegramBotService
from .config import AppConfig, ConfigManager
from .logging_setup import LOG_FILE

APP_STYLE = """
QWidget {
    background: #070c16;
    color: #e8eef8;
    font-size: 13px;
}
QMainWindow {
    background: #070c16;
}
QFrame#HeaderCard {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #141f36, stop:1 #10233f);
    border: 1px solid #2a4168;
    border-radius: 18px;
}
QGroupBox {
    background: #111a2e;
    border: 1px solid #273d62;
    border-radius: 14px;
    margin-top: 10px;
    padding-top: 10px;
}
QGroupBox::title {
    left: 14px;
    padding: 0 6px;
    color: #8ec3ff;
    font-weight: 700;
}
QLineEdit, QPlainTextEdit {
    background: #0a1323;
    border: 1px solid #304a73;
    border-radius: 10px;
    padding: 9px;
    selection-background-color: #3b82f6;
}
QLineEdit:focus, QPlainTextEdit:focus {
    border: 1px solid #5ea6ff;
}
QTabWidget::pane {
    border: 1px solid #253b60;
    border-radius: 12px;
    background: #0b1322;
}
QTabBar::tab {
    background: #15243d;
    border: 1px solid #253b60;
    border-bottom: none;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    padding: 10px 16px;
    margin-right: 6px;
}
QTabBar::tab:selected {
    background: #223a63;
    color: #ffffff;
}
QPushButton {
    background: #2f7df6;
    border: none;
    border-radius: 10px;
    color: white;
    font-weight: 700;
    padding: 10px 16px;
    min-height: 18px;
}
QPushButton:hover {
    background: #4f96ff;
}
QPushButton:disabled {
    background: #3b4f72;
    color: #b8c6dd;
}
QPushButton[secondary="true"] {
    background: #18263f;
}
QPushButton[secondary="true"]:hover {
    background: #263b61;
}
QPushButton[danger="true"] {
    background: #b4233c;
}
QPushButton[danger="true"]:hover {
    background: #d13b54;
}
QCheckBox {
    spacing: 10px;
    padding: 3px 0;
}
QCheckBox::indicator {
    width: 18px;
    height: 18px;
    border-radius: 6px;
    border: 1px solid #35527f;
    background: #0b1528;
}
QCheckBox::indicator:checked {
    background: #347ff0;
    border: 1px solid #76b0ff;
}
QLabel#Title {
    font-size: 30px;
    font-weight: 800;
}
QLabel#Subtitle {
    color: #9cb2d6;
}
QLabel#BadgeOn, QLabel#BadgeOff {
    border-radius: 999px;
    padding: 7px 14px;
    font-weight: 800;
}
QLabel#BadgeOn {
    background: #194f30;
    color: #cbffe0;
}
QLabel#BadgeOff {
    background: #5f2230;
    color: #ffd7de;
}
QLabel#ValueLabel {
    color: #b7c8e7;
}
QScrollArea {
    border: none;
    background: transparent;
}
QScrollBar:vertical {
    border: none;
    background: #0e1930;
    width: 12px;
    margin: 4px 0 4px 0;
    border-radius: 6px;
}
QScrollBar::handle:vertical {
    background: #355989;
    min-height: 24px;
    border-radius: 6px;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    border: none;
    background: none;
    height: 0;
}
"""


class GlowButton(QPushButton):
    def __init__(self, text: str, color: str = '#4f96ff') -> None:
        super().__init__(text)
        self._glow_strength = 0.0
        self._glow_color = QColor(color)

        self._shadow = QGraphicsDropShadowEffect(self)
        self._shadow.setBlurRadius(0)
        self._shadow.setColor(self._glow_color)
        self._shadow.setOffset(0, 0)
        self.setGraphicsEffect(self._shadow)

        self._anim = QPropertyAnimation(self, b'glowStrength', self)
        self._anim.setDuration(180)
        self._anim.setEasingCurve(QEasingCurve.Type.InOutQuad)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def enterEvent(self, event) -> None:  # noqa: N802
        self._animate_glow(1.0)
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:  # noqa: N802
        self._animate_glow(0.0)
        super().leaveEvent(event)

    def _animate_glow(self, target: float) -> None:
        self._anim.stop()
        self._anim.setStartValue(self._glow_strength)
        self._anim.setEndValue(target)
        self._anim.start()

    def _get_glow_strength(self) -> float:
        return self._glow_strength

    def _set_glow_strength(self, value: float) -> None:
        self._glow_strength = max(0.0, min(1.0, value))
        self._shadow.setBlurRadius(4 + (22 * self._glow_strength))
        self._shadow.setColor(QColor(self._glow_color.red(), self._glow_color.green(), self._glow_color.blue(), int(150 * self._glow_strength)))

    glowStrength = Property(float, _get_glow_strength, _set_glow_strength)


class QtLogHandler(logging.Handler):
    def __init__(self, sink) -> None:
        super().__init__()
        self._sink = sink

    def emit(self, record: logging.LogRecord) -> None:
        self._sink(self.format(record))


class MainWindow(QMainWindow):
    def __init__(
        self,
        config_manager: ConfigManager,
        bot_service: TelegramBotService,
        logger: logging.Logger,
        start_minimized: bool = False,
    ) -> None:
        super().__init__()
        self.config_manager = config_manager
        self.bot_service = bot_service
        self.logger = logger
        self._quitting = False
        self._start_minimized = start_minimized

        self.setWindowTitle('PC Controller')
        self.resize(1200, 820)
        self.setMinimumSize(980, 700)
        QApplication.instance().setStyleSheet(APP_STYLE)

        self._build_ui()
        self._setup_tray()
        self._connect_signals()

        self.log_handler = QtLogHandler(self.append_log)
        self.log_handler.setFormatter(logging.Formatter('%(asctime)s | %(levelname)s | %(message)s'))
        self.logger.addHandler(self.log_handler)

        self._load_config_into_form()

        if self.config_manager.current().auto_start_bot:
            QTimer.singleShot(600, lambda: self.start_bot(save_before_start=False))

        if self._start_minimized:
            QTimer.singleShot(0, self.hide)
            self._notify('Application started hidden in tray.')

    def _build_ui(self) -> None:
        root = QWidget(self)
        main_layout = QVBoxLayout(root)
        main_layout.setContentsMargins(16, 16, 16, 16)
        main_layout.setSpacing(14)

        header = QFrame()
        header.setObjectName('HeaderCard')
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(20, 18, 20, 18)
        header_layout.setSpacing(12)

        title_box = QVBoxLayout()
        title = QLabel('PC Controller')
        title.setObjectName('Title')
        subtitle = QLabel('Modern control center with tray mode, autostart and Telegram inline panel.')
        subtitle.setObjectName('Subtitle')
        subtitle.setWordWrap(True)
        title_box.addWidget(title)
        title_box.addWidget(subtitle)

        actions = QHBoxLayout()
        self.save_button = GlowButton('Save Settings')
        self.start_button = GlowButton('Start Bot')
        self.stop_button = GlowButton('Stop Bot')
        self.stop_button.setProperty('secondary', 'true')
        actions.addWidget(self.save_button)
        actions.addWidget(self.start_button)
        actions.addWidget(self.stop_button)
        title_box.addLayout(actions)

        header_layout.addLayout(title_box, stretch=1)
        self.state_badge = QLabel('Bot stopped')
        self.state_badge.setObjectName('BadgeOff')
        header_layout.addWidget(self.state_badge, alignment=Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignTop)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_settings_tab(), 'Settings')
        self.tabs.addTab(self._build_commands_tab(), 'Telegram')
        self.tabs.addTab(self._build_logs_tab(), 'Logs')
        self.tabs.addTab(self._build_about_tab(), 'About')

        main_layout.addWidget(header)
        main_layout.addWidget(self.tabs, stretch=1)
        self.setCentralWidget(root)

    def _build_settings_tab(self) -> QWidget:
        wrapper = QWidget()
        wrapper_layout = QVBoxLayout(wrapper)
        wrapper_layout.setContentsMargins(0, 0, 0, 0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)

        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(12)

        bot_group = QGroupBox('Telegram Bot')
        bot_form = QFormLayout(bot_group)
        bot_form.setSpacing(10)
        self.token_edit = QLineEdit()
        self.token_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.token_edit.setPlaceholderText('Paste BotFather token here')
        self.admins_edit = QPlainTextEdit()
        self.admins_edit.setPlaceholderText('One admin ID per line, or comma separated')
        self.admins_edit.setFixedHeight(120)
        bot_form.addRow('Token', self.token_edit)
        bot_form.addRow('Admin IDs', self.admins_edit)

        startup_group = QGroupBox('Startup')
        startup_layout = QVBoxLayout(startup_group)
        startup_layout.setSpacing(7)
        self.autostart_checkbox = QCheckBox('Start with Windows')
        self.start_minimized_checkbox = QCheckBox('Start minimized to tray')
        self.auto_start_bot_checkbox = QCheckBox('Auto-start Telegram bot with app')
        self.show_notifications_checkbox = QCheckBox('Show tray notifications')
        startup_layout.addWidget(self.autostart_checkbox)
        startup_layout.addWidget(self.start_minimized_checkbox)
        startup_layout.addWidget(self.auto_start_bot_checkbox)
        startup_layout.addWidget(self.show_notifications_checkbox)
        self.autostart_status_label = QLabel('Autostart state: unknown')
        self.autostart_status_label.setObjectName('Subtitle')
        startup_layout.addWidget(self.autostart_status_label)

        startup_buttons = QHBoxLayout()
        self.enable_autostart_button = GlowButton('Enable Autostart')
        self.disable_autostart_button = GlowButton('Disable Autostart')
        self.disable_autostart_button.setProperty('secondary', 'true')
        self.sync_autostart_button = GlowButton('Sync Autostart')
        self.sync_autostart_button.setProperty('secondary', 'true')
        startup_buttons.addWidget(self.enable_autostart_button)
        startup_buttons.addWidget(self.disable_autostart_button)
        startup_buttons.addWidget(self.sync_autostart_button)
        startup_layout.addLayout(startup_buttons)

        security_group = QGroupBox('Permissions')
        security_layout = QVBoxLayout(security_group)
        security_layout.setSpacing(7)
        self.allow_power_commands_checkbox = QCheckBox('Allow power commands')
        self.allow_open_url_checkbox = QCheckBox('Allow open URL command')
        self.allow_file_commands_checkbox = QCheckBox('Allow file manager commands')
        self.allow_process_commands_checkbox = QCheckBox('Allow process commands')
        self.files_root_edit = QLineEdit()
        self.files_root_edit.setPlaceholderText(r'Allowed file root, e.g. C:\Users\Admin')
        root_label = QLabel('Files are restricted to this root folder for safety.')
        root_label.setObjectName('Subtitle')
        root_label.setWordWrap(True)
        security_layout.addWidget(self.allow_power_commands_checkbox)
        security_layout.addWidget(self.allow_open_url_checkbox)
        security_layout.addWidget(self.allow_file_commands_checkbox)
        security_layout.addWidget(self.allow_process_commands_checkbox)
        security_layout.addWidget(self.files_root_edit)
        security_layout.addWidget(root_label)

        paths_group = QGroupBox('Runtime Paths')
        paths_layout = QGridLayout(paths_group)
        paths_layout.setHorizontalSpacing(12)
        paths_layout.setVerticalSpacing(8)
        self.config_path_label = QLabel('')
        self.log_path_label = QLabel('')
        self.executable_path_label = QLabel('')
        self.autostart_command_label = QLabel('')
        for value_label in (self.config_path_label, self.log_path_label, self.executable_path_label, self.autostart_command_label):
            value_label.setObjectName('ValueLabel')
            value_label.setWordWrap(True)
            value_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        paths_layout.addWidget(QLabel('Config'), 0, 0)
        paths_layout.addWidget(self.config_path_label, 0, 1)
        paths_layout.addWidget(QLabel('Log'), 1, 0)
        paths_layout.addWidget(self.log_path_label, 1, 1)
        paths_layout.addWidget(QLabel('Executable'), 2, 0)
        paths_layout.addWidget(self.executable_path_label, 2, 1)
        paths_layout.addWidget(QLabel('Run key command'), 3, 0)
        paths_layout.addWidget(self.autostart_command_label, 3, 1)

        path_buttons = QHBoxLayout()
        self.open_logs_button = GlowButton('Open Logs Folder')
        self.open_logs_button.setProperty('secondary', 'true')
        self.show_config_button = GlowButton('Open Config Folder')
        self.show_config_button.setProperty('secondary', 'true')
        path_buttons.addWidget(self.open_logs_button)
        path_buttons.addWidget(self.show_config_button)

        layout.addWidget(bot_group)
        layout.addWidget(startup_group)
        layout.addWidget(security_group)
        layout.addWidget(paths_group)
        layout.addLayout(path_buttons)
        layout.addStretch(1)

        scroll.setWidget(container)
        wrapper_layout.addWidget(scroll)
        return wrapper

    def _build_commands_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setSpacing(10)

        tip = QLabel('Use /panel in Telegram to open the inline control keyboard.')
        tip.setObjectName('Subtitle')
        tip.setWordWrap(True)

        self.commands_text = QPlainTextEdit()
        self.commands_text.setReadOnly(True)
        self.commands_text.setPlainText(HELP_TEXT)
        self.commands_text.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)

        self.copy_commands_button = GlowButton('Copy Commands')
        self.copy_commands_button.setProperty('secondary', 'true')

        layout.addWidget(tip)
        layout.addWidget(self.commands_text, stretch=1)
        layout.addWidget(self.copy_commands_button)
        return tab

    def _build_logs_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setSpacing(10)

        self.log_output = QPlainTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        controls = QHBoxLayout()
        self.clear_log_view_button = GlowButton('Clear View')
        self.clear_log_view_button.setProperty('secondary', 'true')
        self.refresh_log_view_button = GlowButton('Refresh Last 200 Lines')
        self.refresh_log_view_button.setProperty('secondary', 'true')
        controls.addWidget(self.clear_log_view_button)
        controls.addWidget(self.refresh_log_view_button)

        layout.addWidget(self.log_output, stretch=1)
        layout.addLayout(controls)
        return tab

    def _build_about_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)

        card = QGroupBox('Application Info')
        card_layout = QVBoxLayout(card)
        for text in (
            '• Desktop UI: PySide6',
            '• Telegram bot: python-telegram-bot',
            '• Build: single-file EXE (PyInstaller)',
            '• Autostart: HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run',
            '• Inline panel: /panel command',
        ):
            label = QLabel(text)
            label.setWordWrap(True)
            card_layout.addWidget(label)

        warning = QLabel('Keep bot token private and allow access only for trusted admin IDs.')
        warning.setObjectName('Subtitle')
        warning.setWordWrap(True)

        self.quit_button = GlowButton('Exit Application')
        self.quit_button.setProperty('danger', 'true')

        layout.addWidget(card)
        layout.addWidget(warning)
        layout.addStretch(1)
        layout.addWidget(self.quit_button)
        return tab

    def _setup_tray(self) -> None:
        app = QApplication.instance()
        icon = app.style().standardIcon(QStyle.StandardPixmap.SP_ComputerIcon)
        self.setWindowIcon(icon)
        self.tray_icon = QSystemTrayIcon(icon, self)
        self.tray_icon.setToolTip('PC Controller')

        tray_menu = QMenu(self)
        action_show = QAction('Show Window', self)
        action_hide = QAction('Hide to Tray', self)
        action_start = QAction('Start Bot', self)
        action_stop = QAction('Stop Bot', self)
        action_save = QAction('Save Settings', self)
        action_quit = QAction('Exit', self)
        action_show.triggered.connect(self.show_window)
        action_hide.triggered.connect(self.hide)
        action_start.triggered.connect(lambda: self.start_bot(save_before_start=True))
        action_stop.triggered.connect(self.stop_bot)
        action_save.triggered.connect(self.save_settings)
        action_quit.triggered.connect(self.quit_app)

        tray_menu.addAction(action_show)
        tray_menu.addAction(action_hide)
        tray_menu.addSeparator()
        tray_menu.addAction(action_start)
        tray_menu.addAction(action_stop)
        tray_menu.addAction(action_save)
        tray_menu.addSeparator()
        tray_menu.addAction(action_quit)

        self.tray_icon.setContextMenu(tray_menu)
        self.tray_icon.activated.connect(self._on_tray_activated)
        self.tray_icon.show()

    def _connect_signals(self) -> None:
        self.save_button.clicked.connect(self.save_settings)
        self.start_button.clicked.connect(lambda: self.start_bot(save_before_start=True))
        self.stop_button.clicked.connect(self.stop_bot)
        self.open_logs_button.clicked.connect(self.open_logs_folder)
        self.show_config_button.clicked.connect(self.open_config_folder)
        self.sync_autostart_button.clicked.connect(self.sync_autostart_ui)
        self.enable_autostart_button.clicked.connect(self.enable_autostart_now)
        self.disable_autostart_button.clicked.connect(self.disable_autostart_now)
        self.copy_commands_button.clicked.connect(self.copy_commands_to_clipboard)
        self.clear_log_view_button.clicked.connect(self.log_output.clear)
        self.refresh_log_view_button.clicked.connect(self.load_last_log_lines)
        self.quit_button.clicked.connect(self.quit_app)
        self.bot_service.log_message.connect(self.append_log)
        self.bot_service.state_changed.connect(self.on_bot_state_changed)

    def _load_config_into_form(self) -> None:
        config = self.config_manager.current()
        self.token_edit.setText(config.bot_token)
        self.admins_edit.setPlainText('\n'.join(str(value) for value in config.admin_ids))
        self.autostart_checkbox.setChecked(autostart.is_enabled() or config.autostart)
        self.start_minimized_checkbox.setChecked(config.start_minimized)
        self.auto_start_bot_checkbox.setChecked(config.auto_start_bot)
        self.allow_power_commands_checkbox.setChecked(config.allow_power_commands)
        self.allow_open_url_checkbox.setChecked(config.allow_open_url_command)
        self.allow_file_commands_checkbox.setChecked(config.allow_file_commands)
        self.allow_process_commands_checkbox.setChecked(config.allow_process_commands)
        self.files_root_edit.setText(config.files_root)
        self.show_notifications_checkbox.setChecked(config.show_notifications)
        self._refresh_path_labels()
        self._refresh_autostart_state_label()
        self.load_last_log_lines()
        self.append_log(f'Config loaded from {self.config_manager.path}')

    def _refresh_path_labels(self) -> None:
        self.config_path_label.setText(str(self.config_manager.path))
        self.log_path_label.setText(str(LOG_FILE))
        self.executable_path_label.setText(sys.executable)
        command = autostart.current_command() if autostart.is_enabled() else '(disabled)'
        self.autostart_command_label.setText(command)

    def _refresh_autostart_state_label(self) -> None:
        enabled = autostart.is_enabled()
        self.autostart_status_label.setText(f'Autostart state: {"enabled" if enabled else "disabled"}')
        self.enable_autostart_button.setEnabled(not enabled)
        self.disable_autostart_button.setEnabled(enabled)

    def collect_form(self) -> AppConfig:
        return AppConfig(
            bot_token=self.token_edit.text().strip(),
            admin_ids=ConfigManager.parse_admins(self.admins_edit.toPlainText()),
            autostart=self.autostart_checkbox.isChecked(),
            start_minimized=self.start_minimized_checkbox.isChecked(),
            auto_start_bot=self.auto_start_bot_checkbox.isChecked(),
            allow_power_commands=self.allow_power_commands_checkbox.isChecked(),
            allow_open_url_command=self.allow_open_url_checkbox.isChecked(),
            allow_file_commands=self.allow_file_commands_checkbox.isChecked(),
            allow_process_commands=self.allow_process_commands_checkbox.isChecked(),
            files_root=self.files_root_edit.text().strip(),
            show_notifications=self.show_notifications_checkbox.isChecked(),
        )

    def save_settings(self) -> bool:
        try:
            config = self.collect_form()
        except ValueError:
            QMessageBox.warning(
                self,
                'Invalid Admin IDs',
                'Each admin ID must be a positive integer. Use comma, space or newline separators.',
            )
            return False

        if not config.files_root:
            config.files_root = str(Path.home())

        self.config_manager.save(config)

        try:
            if config.autostart:
                autostart.enable(start_minimized=config.start_minimized)
            else:
                autostart.disable()
        except Exception as exc:
            self.logger.warning('Autostart update failed: %s', exc)
            QMessageBox.warning(self, 'Autostart', f'Failed to update startup setting:\n{exc}')
            return False

        self._refresh_path_labels()
        self._refresh_autostart_state_label()
        self.logger.info('Settings saved. admins=%s, autostart=%s', config.admin_ids, config.autostart)
        self._notify('Settings saved.')
        return True

    def enable_autostart_now(self) -> None:
        self.autostart_checkbox.setChecked(True)
        if self.save_settings():
            self._notify('Autostart enabled.')

    def disable_autostart_now(self) -> None:
        self.autostart_checkbox.setChecked(False)
        if self.save_settings():
            self._notify('Autostart disabled.')

    def start_bot(self, save_before_start: bool = True) -> None:
        if save_before_start and not self.save_settings():
            return
        self.bot_service.start()

    def stop_bot(self) -> None:
        self.bot_service.stop()

    def on_bot_state_changed(self, running: bool) -> None:
        self.state_badge.setText('Bot running' if running else 'Bot stopped')
        self.state_badge.setObjectName('BadgeOn' if running else 'BadgeOff')
        self.start_button.setEnabled(not running)
        self.stop_button.setEnabled(running)
        QApplication.instance().setStyleSheet(APP_STYLE)
        self._notify('Telegram bot started.' if running else 'Telegram bot stopped.')

    def append_log(self, message: str) -> None:
        self.log_output.appendPlainText(message)
        scroll = self.log_output.verticalScrollBar()
        scroll.setValue(scroll.maximum())

    def load_last_log_lines(self) -> None:
        log_path = Path(LOG_FILE)
        if not log_path.exists():
            self.log_output.setPlainText('Log file does not exist yet.')
            return
        lines = log_path.read_text(encoding='utf-8', errors='replace').splitlines()
        self.log_output.setPlainText('\n'.join(lines[-200:]))

    def open_logs_folder(self) -> None:
        Path(LOG_FILE).parent.mkdir(parents=True, exist_ok=True)
        startfile(str(Path(LOG_FILE).parent))

    def open_config_folder(self) -> None:
        self.config_manager.path.parent.mkdir(parents=True, exist_ok=True)
        startfile(str(self.config_manager.path.parent))

    def sync_autostart_ui(self) -> None:
        enabled = autostart.is_enabled()
        self.autostart_checkbox.setChecked(enabled)
        self._refresh_path_labels()
        self._refresh_autostart_state_label()
        self.append_log(f'Autostart registry state: {"enabled" if enabled else "disabled"}')

    def copy_commands_to_clipboard(self) -> None:
        QApplication.clipboard().setText(HELP_TEXT)
        self._notify('Command list copied.')

    def show_window(self) -> None:
        self.showNormal()
        self.activateWindow()
        self.raise_()

    def _on_tray_activated(self, reason: QSystemTrayIcon.ActivationReason) -> None:
        if reason == QSystemTrayIcon.ActivationReason.DoubleClick:
            if self.isVisible():
                self.hide()
            else:
                self.show_window()

    def _notify(self, text: str) -> None:
        if not self.config_manager.current().show_notifications:
            return
        self.tray_icon.showMessage('PC Controller', text)

    def closeEvent(self, event) -> None:  # noqa: N802
        if self._quitting:
            super().closeEvent(event)
            return
        event.ignore()
        self.hide()
        self._notify('Window hidden to tray. App still runs.')

    def quit_app(self) -> None:
        self._quitting = True
        self.bot_service.shutdown()
        self.tray_icon.hide()
        self.close()
        QApplication.instance().quit()
