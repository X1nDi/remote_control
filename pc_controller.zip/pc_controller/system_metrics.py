from __future__ import annotations

import platform
import socket
import time
from dataclasses import dataclass
from datetime import datetime
from io import BytesIO
from pathlib import Path

import psutil
from PIL import ImageGrab


@dataclass(slots=True)
class RuntimeSnapshot:
    hostname: str
    os_name: str
    os_release: str
    python_version: str
    ip_address: str
    cpu_percent: float
    memory_percent: float
    disk_percent: float
    uptime_seconds: int
    admin_count: int
    autostart_enabled: bool
    bot_running: bool


def collect_snapshot(admin_count: int, autostart_enabled: bool, bot_running: bool) -> RuntimeSnapshot:
    boot_time = psutil.boot_time()
    uptime_seconds = max(0, int(time.time() - boot_time))
    disk_root = _disk_root()

    return RuntimeSnapshot(
        hostname=socket.gethostname(),
        os_name=platform.system(),
        os_release=platform.release(),
        python_version=platform.python_version(),
        ip_address=_local_ip(),
        cpu_percent=psutil.cpu_percent(interval=0.2),
        memory_percent=psutil.virtual_memory().percent,
        disk_percent=psutil.disk_usage(str(disk_root)).percent,
        uptime_seconds=uptime_seconds,
        admin_count=admin_count,
        autostart_enabled=autostart_enabled,
        bot_running=bot_running,
    )


def format_snapshot(snapshot: RuntimeSnapshot) -> str:
    return (
        'PC Controller status:\n'
        f'• Host: {snapshot.hostname}\n'
        f'• OS: {snapshot.os_name} {snapshot.os_release}\n'
        f'• IP: {snapshot.ip_address}\n'
        f'• Python: {snapshot.python_version}\n'
        f'• CPU: {snapshot.cpu_percent:.1f}%\n'
        f'• RAM: {snapshot.memory_percent:.1f}%\n'
        f'• Disk: {snapshot.disk_percent:.1f}%\n'
        f'• Uptime: {format_uptime(snapshot.uptime_seconds)}\n'
        f'• Admins: {snapshot.admin_count}\n'
        f'• Autostart: {"ON" if snapshot.autostart_enabled else "OFF"}\n'
        f'• Bot: {"running" if snapshot.bot_running else "stopped"}'
    )


def format_uptime(total_seconds: int) -> str:
    days, rem = divmod(max(total_seconds, 0), 86_400)
    hours, rem = divmod(rem, 3_600)
    minutes, seconds = divmod(rem, 60)
    if days:
        return f'{days}d {hours:02d}:{minutes:02d}:{seconds:02d}'
    return f'{hours:02d}:{minutes:02d}:{seconds:02d}'


def capture_screenshot_bytes() -> tuple[bytes, str]:
    image = ImageGrab.grab(all_screens=True)
    now = datetime.now().strftime('%Y%m%d_%H%M%S')
    file_name = f'screenshot_{now}.jpg'
    output = BytesIO()
    image.convert('RGB').save(output, format='JPEG', quality=86)
    return output.getvalue(), file_name


def _disk_root() -> Path:
    home = Path.home()
    drive = home.drive
    if drive:
        return Path(f'{drive}\\')
    return Path('/')


def _local_ip() -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.connect(('8.8.8.8', 80))
            return str(sock.getsockname()[0])
    except OSError:
        return 'unknown'
