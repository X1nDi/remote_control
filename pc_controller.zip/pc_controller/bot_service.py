from __future__ import annotations

import asyncio
import os
import shutil
import threading
from io import BytesIO
from pathlib import Path
from typing import Callable

import psutil
from PySide6.QtCore import QObject, Signal
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import (
    Application,
    ApplicationBuilder,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

from .config import AppConfig
from .logging_setup import LOG_FILE
from .system_actions import (
    cancel_scheduled_power_action,
    lock_workstation,
    open_url,
    parse_delay,
    schedule_reboot,
    schedule_shutdown,
    sleep_system,
)
from .system_metrics import capture_screenshot_bytes, collect_snapshot, format_snapshot, format_uptime

MAX_DOWNLOAD_FILE_SIZE = 45 * 1024 * 1024
MAX_LIST_ITEMS = 120

HELP_TEXT = (
    'PC Controller commands:\n'
    '/help - show this list\n'
    '/panel - open inline control panel\n'
    '/myid - show your Telegram ID\n'
    '/ping - health check\n'
    '/status - app and machine status\n'
    '/uptime - machine uptime\n'
    '/screenshot - send desktop screenshot\n'
    '/lock - lock workstation\n'
    '/shutdown [sec] - shutdown after delay\n'
    '/reboot [sec] - reboot after delay\n'
    '/cancelshutdown - cancel pending shutdown/reboot\n'
    '/sleep - put PC to sleep\n'
    '/openurl <https://...> - open URL in browser\n'
    '/logtail [n] - send last lines from app log\n'
    '/pwd - show current working directory\n'
    '/ls [path] - list files in directory\n'
    '/cd <path> - change working directory\n'
    '/mkdir <path> - create directory\n'
    '/rm <path> - delete file or empty directory\n'
    '/rmr <path> - delete file or directory recursively\n'
    '/download <path> - send file from PC\n'
    '/upload [path] - wait for Telegram document and save to path\n'
    '/cancelupload - cancel pending upload operation\n'
    '/tasklist [filter] - show running processes\n'
    '/taskkill <pid> - terminate process by pid'
)


class TelegramBotService(QObject):
    log_message = Signal(str)
    state_changed = Signal(bool)

    def __init__(self, config_provider: Callable[[], AppConfig]) -> None:
        super().__init__()
        self._config_provider = config_provider
        self._thread: threading.Thread | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._application: Application | None = None
        self._stop_event = threading.Event()
        self._running = False
        self._cwd_by_user: dict[int, Path] = {}
        self._pending_upload_by_user: dict[int, Path] = {}

    @property
    def running(self) -> bool:
        return self._running

    def start(self) -> None:
        if self._running:
            self.log_message.emit('Bot is already running.')
            return

        config = self._config_provider()
        if not config.bot_token.strip():
            self.log_message.emit('Bot token is empty. Set it in settings first.')
            return
        if not config.admin_ids:
            self.log_message.emit('Admin IDs list is empty. Add at least one admin ID.')
            return

        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run_in_thread, name='telegram-bot-thread', daemon=True)
        self._thread.start()

    def stop(self) -> None:
        thread_alive = self._thread is not None and self._thread.is_alive()
        if not self._running and not thread_alive:
            self.log_message.emit('Bot is already stopped.')
            return

        self._stop_event.set()
        if self._loop is not None:
            self._loop.call_soon_threadsafe(lambda: None)

    def shutdown(self) -> None:
        self.stop()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=4)
        self._thread = None

    async def _command_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return
        await self._safe_reply(update, HELP_TEXT, reply_markup=self._panel_main_markup())

    async def _command_help(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        await self._command_start(update, context)

    async def _command_panel(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return
        await self._safe_reply(
            update,
            'Inline panel opened. Use buttons below for quick control.',
            reply_markup=self._panel_main_markup(),
        )

    async def _command_myid(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        user = update.effective_user
        if user is None:
            return
        await self._safe_reply(update, f'Your Telegram ID: {user.id}')

    async def _command_ping(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return
        await self._safe_reply(update, 'pong')

    async def _command_status(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return

        config = self._config_provider()
        snapshot = await asyncio.to_thread(
            collect_snapshot,
            len(config.admin_ids),
            config.autostart,
            self._running,
        )
        await self._safe_reply(update, format_snapshot(snapshot))

    async def _command_uptime(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return

        config = self._config_provider()
        snapshot = await asyncio.to_thread(
            collect_snapshot,
            len(config.admin_ids),
            config.autostart,
            self._running,
        )
        await self._safe_reply(update, f'Uptime: {format_uptime(snapshot.uptime_seconds)}')

    async def _command_screenshot(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return

        try:
            screenshot_bytes, file_name = await asyncio.to_thread(capture_screenshot_bytes)
            stream = BytesIO(screenshot_bytes)
            stream.name = file_name
            if update.effective_message:
                await update.effective_message.reply_photo(photo=stream, caption='Current desktop screenshot.')
            self.log_message.emit(f'Screenshot sent to admin {update.effective_user.id}.')
        except Exception as exc:
            self.log_message.emit(f'Failed to capture screenshot: {exc}')
            await self._safe_reply(update, f'Failed to capture screenshot: {exc}')

    async def _command_lock(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return

        try:
            result = await asyncio.to_thread(lock_workstation)
            self.log_message.emit(result.message)
            await self._safe_reply(update, result.message)
        except Exception as exc:
            self.log_message.emit(f'Lock command failed: {exc}')
            await self._safe_reply(update, f'Lock command failed: {exc}')

    async def _command_shutdown(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return
        if not self._config_provider().allow_power_commands:
            await self._safe_reply(update, 'Power commands are disabled in app settings.')
            return

        try:
            delay = parse_delay(context.args[0] if context.args else None)
            result = await asyncio.to_thread(schedule_shutdown, delay)
            self.log_message.emit(result.message)
            await self._safe_reply(update, result.message)
        except ValueError as exc:
            await self._safe_reply(update, f'Usage: /shutdown [seconds]\nError: {exc}')
        except Exception as exc:
            self.log_message.emit(f'Shutdown command failed: {exc}')
            await self._safe_reply(update, f'Shutdown command failed: {exc}')

    async def _command_reboot(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return
        if not self._config_provider().allow_power_commands:
            await self._safe_reply(update, 'Power commands are disabled in app settings.')
            return

        try:
            delay = parse_delay(context.args[0] if context.args else None)
            result = await asyncio.to_thread(schedule_reboot, delay)
            self.log_message.emit(result.message)
            await self._safe_reply(update, result.message)
        except ValueError as exc:
            await self._safe_reply(update, f'Usage: /reboot [seconds]\nError: {exc}')
        except Exception as exc:
            self.log_message.emit(f'Reboot command failed: {exc}')
            await self._safe_reply(update, f'Reboot command failed: {exc}')

    async def _command_cancel_shutdown(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return
        if not self._config_provider().allow_power_commands:
            await self._safe_reply(update, 'Power commands are disabled in app settings.')
            return

        try:
            result = await asyncio.to_thread(cancel_scheduled_power_action)
            self.log_message.emit(result.message)
            await self._safe_reply(update, result.message)
        except Exception as exc:
            self.log_message.emit(f'Cancel shutdown command failed: {exc}')
            await self._safe_reply(update, f'Cancel shutdown command failed: {exc}')

    async def _command_sleep(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return
        if not self._config_provider().allow_power_commands:
            await self._safe_reply(update, 'Power commands are disabled in app settings.')
            return

        try:
            result = await asyncio.to_thread(sleep_system)
            self.log_message.emit(result.message)
            await self._safe_reply(update, result.message)
        except Exception as exc:
            self.log_message.emit(f'Sleep command failed: {exc}')
            await self._safe_reply(update, f'Sleep command failed: {exc}')

    async def _command_open_url(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return
        if not self._config_provider().allow_open_url_command:
            await self._safe_reply(update, 'URL open command is disabled in app settings.')
            return

        if not context.args:
            await self._safe_reply(update, 'Usage: /openurl <https://example.com>')
            return

        url = context.args[0].strip()
        try:
            result = await asyncio.to_thread(open_url, url)
            self.log_message.emit(result.message)
            await self._safe_reply(update, result.message)
        except ValueError as exc:
            await self._safe_reply(update, f'Invalid URL: {exc}')
        except Exception as exc:
            self.log_message.emit(f'Open URL command failed: {exc}')
            await self._safe_reply(update, f'Open URL command failed: {exc}')

    async def _command_log_tail(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return

        lines_count = 40
        if context.args:
            try:
                lines_count = max(1, min(200, int(context.args[0])))
            except ValueError:
                await self._safe_reply(update, 'Usage: /logtail [1..200]')
                return

        text = await asyncio.to_thread(self._read_log_tail, lines_count)
        await self._safe_reply(update, text)

    async def _command_pwd(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return
        if not self._config_provider().allow_file_commands:
            await self._safe_reply(update, 'File commands are disabled in app settings.')
            return

        user_id = update.effective_user.id
        root = self._base_root()
        cwd = self._cwd_by_user.get(user_id, root)
        if not self._is_allowed_path(cwd, root):
            cwd = root
            self._cwd_by_user[user_id] = root
        await self._safe_reply(update, f'Root: {root}\nCurrent directory: {cwd}')

    async def _command_ls(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return
        if not self._config_provider().allow_file_commands:
            await self._safe_reply(update, 'File commands are disabled in app settings.')
            return

        user_id = update.effective_user.id
        raw_path = ' '.join(context.args).strip() if context.args else ''
        try:
            target = self._resolve_user_path(user_id, raw_path)
            text = await asyncio.to_thread(self._build_dir_listing_text, target)
            await self._safe_reply(update, text)
        except Exception as exc:
            await self._safe_reply(update, f'/ls failed: {exc}')

    async def _command_cd(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return
        if not self._config_provider().allow_file_commands:
            await self._safe_reply(update, 'File commands are disabled in app settings.')
            return

        if not context.args:
            await self._safe_reply(update, 'Usage: /cd <path>')
            return

        user_id = update.effective_user.id
        raw_path = ' '.join(context.args).strip()
        try:
            target = self._resolve_user_path(user_id, raw_path)
            if not target.exists() or not target.is_dir():
                raise ValueError('Directory does not exist.')
            self._cwd_by_user[user_id] = target
            await self._safe_reply(update, f'Current directory changed to: {target}')
        except Exception as exc:
            await self._safe_reply(update, f'/cd failed: {exc}')

    async def _command_mkdir(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return
        if not self._config_provider().allow_file_commands:
            await self._safe_reply(update, 'File commands are disabled in app settings.')
            return

        if not context.args:
            await self._safe_reply(update, 'Usage: /mkdir <path>')
            return

        user_id = update.effective_user.id
        raw_path = ' '.join(context.args).strip()
        try:
            target = self._resolve_user_path(user_id, raw_path)
            target.mkdir(parents=True, exist_ok=False)
            await self._safe_reply(update, f'Directory created: {target}')
        except FileExistsError:
            await self._safe_reply(update, 'Directory already exists.')
        except Exception as exc:
            await self._safe_reply(update, f'/mkdir failed: {exc}')

    async def _command_rm(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return
        if not self._config_provider().allow_file_commands:
            await self._safe_reply(update, 'File commands are disabled in app settings.')
            return

        if not context.args:
            await self._safe_reply(update, 'Usage: /rm <path>')
            return

        user_id = update.effective_user.id
        raw_path = ' '.join(context.args).strip()
        try:
            target = self._resolve_user_path(user_id, raw_path)
            await asyncio.to_thread(self._remove_path, target, False)
            await self._safe_reply(update, f'Removed: {target}')
        except Exception as exc:
            await self._safe_reply(update, f'/rm failed: {exc}')

    async def _command_rmr(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return
        if not self._config_provider().allow_file_commands:
            await self._safe_reply(update, 'File commands are disabled in app settings.')
            return

        if not context.args:
            await self._safe_reply(update, 'Usage: /rmr <path>')
            return

        user_id = update.effective_user.id
        raw_path = ' '.join(context.args).strip()
        try:
            target = self._resolve_user_path(user_id, raw_path)
            await asyncio.to_thread(self._remove_path, target, True)
            await self._safe_reply(update, f'Removed recursively: {target}')
        except Exception as exc:
            await self._safe_reply(update, f'/rmr failed: {exc}')

    async def _command_download(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return
        if not self._config_provider().allow_file_commands:
            await self._safe_reply(update, 'File commands are disabled in app settings.')
            return

        if not context.args:
            await self._safe_reply(update, 'Usage: /download <path>')
            return

        user_id = update.effective_user.id
        raw_path = ' '.join(context.args).strip()
        try:
            target = self._resolve_user_path(user_id, raw_path)
            if not target.exists() or not target.is_file():
                raise ValueError('File does not exist.')
            size = target.stat().st_size
            if size > MAX_DOWNLOAD_FILE_SIZE:
                raise ValueError(
                    f'File is too large ({self._format_bytes(size)}). Limit is {self._format_bytes(MAX_DOWNLOAD_FILE_SIZE)}.'
                )
            if update.effective_message:
                with target.open('rb') as file_stream:
                    await update.effective_message.reply_document(
                        document=file_stream,
                        filename=target.name,
                        caption=f'{target.name} ({self._format_bytes(size)})',
                    )
            self.log_message.emit(f'File sent to admin {user_id}: {target}')
        except Exception as exc:
            await self._safe_reply(update, f'/download failed: {exc}')

    async def _command_upload(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return
        if not self._config_provider().allow_file_commands:
            await self._safe_reply(update, 'File commands are disabled in app settings.')
            return

        user_id = update.effective_user.id
        raw_path = ' '.join(context.args).strip() if context.args else ''
        try:
            target_dir = self._resolve_user_path(user_id, raw_path)
            if not target_dir.exists() or not target_dir.is_dir():
                raise ValueError('Target directory does not exist.')
            self._pending_upload_by_user[user_id] = target_dir
            await self._safe_reply(
                update,
                f'Upload mode enabled for:\n{target_dir}\nSend a Telegram document now. Use /cancelupload to cancel.',
            )
        except Exception as exc:
            await self._safe_reply(update, f'/upload failed: {exc}')

    async def _command_cancel_upload(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return

        user_id = update.effective_user.id
        if user_id in self._pending_upload_by_user:
            self._pending_upload_by_user.pop(user_id, None)
            await self._safe_reply(update, 'Upload mode canceled.')
            return
        await self._safe_reply(update, 'Upload mode is not active.')

    async def _handle_document_upload(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return
        if not self._config_provider().allow_file_commands:
            return

        user_id = update.effective_user.id
        target_dir = self._pending_upload_by_user.get(user_id)
        if target_dir is None:
            return

        message = update.effective_message
        if message is None or message.document is None:
            return

        try:
            root = self._base_root()
            if not self._is_allowed_path(target_dir, root):
                raise ValueError('Upload target is outside allowed root.')
            target_dir.mkdir(parents=True, exist_ok=True)
            file_name = self._sanitize_upload_name(message.document.file_name)
            destination = self._build_unique_destination(target_dir / file_name)
            telegram_file = await message.document.get_file()
            await telegram_file.download_to_drive(custom_path=str(destination))
            size = destination.stat().st_size
            self.log_message.emit(f'File uploaded by admin {user_id}: {destination}')
            await self._safe_reply(update, f'Uploaded: {destination}\nSize: {self._format_bytes(size)}')
        except Exception as exc:
            await self._safe_reply(update, f'Upload failed: {exc}')
        finally:
            self._pending_upload_by_user.pop(user_id, None)

    async def _command_tasklist(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return
        if not self._config_provider().allow_process_commands:
            await self._safe_reply(update, 'Process commands are disabled in app settings.')
            return

        filter_text = ' '.join(context.args).strip().lower() if context.args else ''
        text = await asyncio.to_thread(self._build_tasklist_text, filter_text)
        await self._safe_reply(update, text)

    async def _command_taskkill(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return
        if not self._config_provider().allow_process_commands:
            await self._safe_reply(update, 'Process commands are disabled in app settings.')
            return

        if not context.args:
            await self._safe_reply(update, 'Usage: /taskkill <pid>')
            return

        try:
            pid = int(context.args[0])
            message = await asyncio.to_thread(self._terminate_pid, pid)
            await self._safe_reply(update, message)
        except ValueError:
            await self._safe_reply(update, 'PID should be an integer.')
        except Exception as exc:
            await self._safe_reply(update, f'/taskkill failed: {exc}')

    async def _handle_panel_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        query = update.callback_query
        if query is None:
            return
        await query.answer()
        if not await self._ensure_admin(update):
            return

        data = str(query.data or '')
        if data == 'panel:main':
            await self._edit_panel_message(query, 'Control panel', self._panel_main_markup())
            return
        if data == 'panel:help':
            await self._safe_reply(update, HELP_TEXT, reply_markup=self._panel_main_markup())
            return
        if data == 'panel:status':
            await self._command_status(update, context)
            return
        if data == 'panel:screenshot':
            await self._command_screenshot(update, context)
            return
        if data == 'panel:files':
            await self._edit_panel_message(query, 'Files panel', self._panel_files_markup())
            return
        if data == 'panel:process':
            await self._edit_panel_message(query, 'Process panel', self._panel_process_markup())
            return
        if data == 'panel:power':
            await self._edit_panel_message(query, 'Power panel', self._panel_power_markup())
            return
        if data == 'panel:logs':
            await self._edit_panel_message(query, 'Logs panel', self._panel_logs_markup())
            return

        if data == 'panel:files:pwd':
            await self._command_pwd(update, context)
            return
        if data == 'panel:files:ls':
            await self._command_ls(update, context)
            return
        if data == 'panel:files:upload':
            user_id = update.effective_user.id
            cwd = self._resolve_user_path(user_id, None)
            self._pending_upload_by_user[user_id] = cwd
            await self._safe_reply(
                update,
                f'Upload mode enabled for:\n{cwd}\nSend a Telegram document now. Use /cancelupload to cancel.',
            )
            return
        if data == 'panel:files:cancelupload':
            await self._command_cancel_upload(update, context)
            return

        if data == 'panel:proc:list':
            await self._command_tasklist(update, context)
            return

        if data == 'panel:power:lock':
            await self._command_lock(update, context)
            return
        if data == 'panel:power:sleep':
            await self._command_sleep(update, context)
            return
        if data == 'panel:power:shutdown60':
            await self._execute_power_action(update, action='shutdown', delay=60)
            return
        if data == 'panel:power:reboot60':
            await self._execute_power_action(update, action='reboot', delay=60)
            return
        if data == 'panel:power:cancel':
            await self._command_cancel_shutdown(update, context)
            return

        if data == 'panel:logs:tail40':
            text = await asyncio.to_thread(self._read_log_tail, 40)
            await self._safe_reply(update, text)
            return

        await self._safe_reply(update, 'Unknown panel action.')

    async def _execute_power_action(self, update: Update, action: str, delay: int) -> None:
        if not self._config_provider().allow_power_commands:
            await self._safe_reply(update, 'Power commands are disabled in app settings.')
            return

        try:
            if action == 'shutdown':
                result = await asyncio.to_thread(schedule_shutdown, delay)
            elif action == 'reboot':
                result = await asyncio.to_thread(schedule_reboot, delay)
            else:
                raise ValueError('Unknown power action.')
            self.log_message.emit(result.message)
            await self._safe_reply(update, result.message)
        except Exception as exc:
            await self._safe_reply(update, f'Power action failed: {exc}')

    async def _edit_panel_message(self, query, title: str, markup: InlineKeyboardMarkup) -> None:
        try:
            await query.edit_message_text(title, reply_markup=markup)
        except Exception:
            if query.message:
                await query.message.reply_text(title, reply_markup=markup)

    @staticmethod
    def _panel_main_markup() -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton('📊 Status', callback_data='panel:status'),
                    InlineKeyboardButton('🖼 Screenshot', callback_data='panel:screenshot'),
                ],
                [
                    InlineKeyboardButton('📁 Files', callback_data='panel:files'),
                    InlineKeyboardButton('⚙️ Processes', callback_data='panel:process'),
                ],
                [
                    InlineKeyboardButton('🔋 Power', callback_data='panel:power'),
                    InlineKeyboardButton('🧾 Logs', callback_data='panel:logs'),
                ],
                [InlineKeyboardButton('❓ Help', callback_data='panel:help')],
            ]
        )

    @staticmethod
    def _panel_files_markup() -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton('PWD', callback_data='panel:files:pwd'),
                    InlineKeyboardButton('LS', callback_data='panel:files:ls'),
                ],
                [
                    InlineKeyboardButton('Upload Here', callback_data='panel:files:upload'),
                    InlineKeyboardButton('Cancel Upload', callback_data='panel:files:cancelupload'),
                ],
                [InlineKeyboardButton('⬅️ Back', callback_data='panel:main')],
            ]
        )

    @staticmethod
    def _panel_process_markup() -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup(
            [
                [InlineKeyboardButton('Tasklist', callback_data='panel:proc:list')],
                [InlineKeyboardButton('⬅️ Back', callback_data='panel:main')],
            ]
        )

    @staticmethod
    def _panel_power_markup() -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton('🔒 Lock', callback_data='panel:power:lock'),
                    InlineKeyboardButton('🌙 Sleep', callback_data='panel:power:sleep'),
                ],
                [
                    InlineKeyboardButton('⏻ Shutdown 60s', callback_data='panel:power:shutdown60'),
                    InlineKeyboardButton('🔄 Reboot 60s', callback_data='panel:power:reboot60'),
                ],
                [InlineKeyboardButton('✋ Cancel Power Action', callback_data='panel:power:cancel')],
                [InlineKeyboardButton('⬅️ Back', callback_data='panel:main')],
            ]
        )

    @staticmethod
    def _panel_logs_markup() -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup(
            [
                [InlineKeyboardButton('Last 40 log lines', callback_data='panel:logs:tail40')],
                [InlineKeyboardButton('⬅️ Back', callback_data='panel:main')],
            ]
        )

    async def _command_unknown(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_admin(update):
            return
        await self._safe_reply(update, 'Unknown command. Use /help to see available commands.')

    async def _error_handler(self, update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
        self.log_message.emit(f'Unhandled bot error: {context.error}')
        if isinstance(update, Update):
            await self._safe_reply(update, 'Internal bot error. Check application logs.')

    async def _ensure_admin(self, update: Update) -> bool:
        user = update.effective_user
        user_id = getattr(user, 'id', None)
        if user_id is None:
            return False

        if user_id not in self._config_provider().admin_ids:
            self.log_message.emit(f'Access denied for user_id={user_id}')
            await self._safe_reply(update, 'Access denied. Your Telegram ID is not in admin list.')
            return False
        return True

    async def _safe_reply(self, update: Update, text: str, reply_markup: InlineKeyboardMarkup | None = None) -> None:
        message = update.effective_message
        if message is None:
            return

        clipped = text.strip()
        if len(clipped) <= 3900:
            await message.reply_text(clipped, reply_markup=reply_markup)
            return

        chunks = [clipped[i : i + 3800] for i in range(0, len(clipped), 3800)]
        for index, chunk in enumerate(chunks):
            await message.reply_text(chunk, reply_markup=reply_markup if index == 0 else None)

    def _run_in_thread(self) -> None:
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._runner())
        except Exception as exc:
            self.log_message.emit(f'Bot startup failed: {exc}')
        finally:
            self._running = False
            self.state_changed.emit(False)
            if self._loop and self._loop.is_running():
                self._loop.stop()
            if self._loop:
                self._loop.close()
            self._loop = None
            self._thread = None

    async def _runner(self) -> None:
        config = self._config_provider()
        self._application = ApplicationBuilder().token(config.bot_token.strip()).build()
        self._application.add_handler(CommandHandler('start', self._command_start))
        self._application.add_handler(CommandHandler('help', self._command_help))
        self._application.add_handler(CommandHandler('panel', self._command_panel))
        self._application.add_handler(CommandHandler('myid', self._command_myid))
        self._application.add_handler(CommandHandler('ping', self._command_ping))
        self._application.add_handler(CommandHandler('status', self._command_status))
        self._application.add_handler(CommandHandler('uptime', self._command_uptime))
        self._application.add_handler(CommandHandler('screenshot', self._command_screenshot))
        self._application.add_handler(CommandHandler('lock', self._command_lock))
        self._application.add_handler(CommandHandler('shutdown', self._command_shutdown))
        self._application.add_handler(CommandHandler('reboot', self._command_reboot))
        self._application.add_handler(CommandHandler('cancelshutdown', self._command_cancel_shutdown))
        self._application.add_handler(CommandHandler('sleep', self._command_sleep))
        self._application.add_handler(CommandHandler('openurl', self._command_open_url))
        self._application.add_handler(CommandHandler('logtail', self._command_log_tail))
        self._application.add_handler(CommandHandler('pwd', self._command_pwd))
        self._application.add_handler(CommandHandler('ls', self._command_ls))
        self._application.add_handler(CommandHandler('cd', self._command_cd))
        self._application.add_handler(CommandHandler('mkdir', self._command_mkdir))
        self._application.add_handler(CommandHandler('rm', self._command_rm))
        self._application.add_handler(CommandHandler('rmr', self._command_rmr))
        self._application.add_handler(CommandHandler('download', self._command_download))
        self._application.add_handler(CommandHandler('upload', self._command_upload))
        self._application.add_handler(CommandHandler('cancelupload', self._command_cancel_upload))
        self._application.add_handler(CommandHandler('tasklist', self._command_tasklist))
        self._application.add_handler(CommandHandler('taskkill', self._command_taskkill))
        self._application.add_handler(CallbackQueryHandler(self._handle_panel_callback, pattern=r'^panel:'))
        self._application.add_handler(MessageHandler(filters.Document.ALL, self._handle_document_upload))
        self._application.add_handler(MessageHandler(filters.COMMAND, self._command_unknown))
        self._application.add_error_handler(self._error_handler)

        await self._application.initialize()
        await self._application.start()
        if self._application.updater is None:
            raise RuntimeError('Telegram updater is not available.')
        await self._application.updater.start_polling(drop_pending_updates=True)

        self._running = True
        self.state_changed.emit(True)
        self.log_message.emit('Bot started successfully.')

        try:
            while not self._stop_event.is_set():
                await asyncio.sleep(0.3)
        finally:
            self.log_message.emit('Stopping bot...')
            if self._application and self._application.updater:
                await self._application.updater.stop()
            if self._application:
                await self._application.stop()
                await self._application.shutdown()
            self._application = None
            self._pending_upload_by_user.clear()
            self.log_message.emit('Bot stopped.')

    def _base_root(self) -> Path:
        config = self._config_provider()
        root_raw = (config.files_root or '').strip()
        root = Path(root_raw).expanduser() if root_raw else Path.home()
        root.mkdir(parents=True, exist_ok=True)
        return root.resolve(strict=False)

    def _resolve_user_path(self, user_id: int, raw_path: str | None) -> Path:
        root = self._base_root()
        cwd = self._cwd_by_user.get(user_id, root)
        if not self._is_allowed_path(cwd, root):
            cwd = root
            self._cwd_by_user[user_id] = root

        if raw_path:
            cleaned = raw_path.strip().strip('"').strip("'")
            candidate = Path(cleaned)
            target = candidate if candidate.is_absolute() else (cwd / candidate)
        else:
            target = cwd

        resolved = target.resolve(strict=False)
        if not self._is_allowed_path(resolved, root):
            raise ValueError(f'Path is outside allowed root: {root}')
        return resolved

    @staticmethod
    def _is_allowed_path(target: Path, root: Path) -> bool:
        try:
            target.relative_to(root)
            return True
        except ValueError:
            return False

    def _build_dir_listing_text(self, target: Path) -> str:
        if not target.exists():
            raise ValueError('Path does not exist.')

        if target.is_file():
            size = target.stat().st_size
            return f'File:\n{target}\nSize: {self._format_bytes(size)}'

        entries = sorted(target.iterdir(), key=lambda item: (not item.is_dir(), item.name.lower()))
        lines = [f'Directory: {target}', f'Items: {len(entries)}']
        limit = min(len(entries), MAX_LIST_ITEMS)
        for entry in entries[:limit]:
            icon = '📁' if entry.is_dir() else '📄'
            if entry.is_dir():
                details = '<DIR>'
            else:
                details = self._format_bytes(entry.stat().st_size)
            lines.append(f'{icon} {entry.name}  ({details})')
        if len(entries) > limit:
            lines.append(f'... and {len(entries) - limit} more items.')
        return '\n'.join(lines)

    def _remove_path(self, target: Path, recursive: bool) -> None:
        root = self._base_root()
        if not target.exists():
            raise ValueError('Path does not exist.')
        if target.resolve(strict=False) == root:
            raise ValueError('Cannot remove allowed root directory.')

        if target.is_file():
            target.unlink()
            return

        if recursive:
            shutil.rmtree(target)
            return

        target.rmdir()

    def _build_tasklist_text(self, filter_text: str) -> str:
        records: list[tuple[int, str, float]] = []
        for process in psutil.process_iter(['pid', 'name', 'memory_info']):
            try:
                info = process.info
                process_name = str(info.get('name') or 'unknown')
                if filter_text and filter_text not in process_name.lower():
                    continue
                mem_info = info.get('memory_info')
                memory_mb = float(mem_info.rss / (1024 * 1024)) if mem_info else 0.0
                records.append((int(info['pid']), process_name, memory_mb))
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue

        if not records:
            return 'No processes matched your filter.'

        records.sort(key=lambda row: row[2], reverse=True)
        top = records[:60]
        lines = ['Top processes by RAM usage:']
        for pid, name, memory_mb in top:
            lines.append(f'PID {pid:>6} | {memory_mb:>8.1f} MB | {name}')
        if len(records) > len(top):
            lines.append(f'... and {len(records) - len(top)} more.')
        return '\n'.join(lines)

    @staticmethod
    def _terminate_pid(pid: int) -> str:
        if pid <= 0:
            raise ValueError('PID should be greater than zero.')
        if pid == os.getpid():
            raise ValueError('Refusing to terminate controller process.')

        process = psutil.Process(pid)
        name = process.name()
        process.terminate()
        try:
            process.wait(timeout=4)
            return f'Process terminated: PID {pid} ({name})'
        except psutil.TimeoutExpired:
            process.kill()
            process.wait(timeout=4)
            return f'Process killed: PID {pid} ({name})'

    @staticmethod
    def _sanitize_upload_name(file_name: str | None) -> str:
        candidate = Path(file_name or '').name.strip()
        return candidate or 'uploaded_file.bin'

    @staticmethod
    def _build_unique_destination(base_path: Path) -> Path:
        if not base_path.exists():
            return base_path
        stem = base_path.stem
        suffix = base_path.suffix
        index = 1
        while True:
            candidate = base_path.with_name(f'{stem}_{index}{suffix}')
            if not candidate.exists():
                return candidate
            index += 1

    @staticmethod
    def _format_bytes(size: int) -> str:
        units = ('B', 'KB', 'MB', 'GB', 'TB')
        value = float(size)
        for unit in units:
            if value < 1024.0 or unit == units[-1]:
                return f'{value:.1f} {unit}'
            value /= 1024.0
        return f'{value:.1f} TB'

    @staticmethod
    def _read_log_tail(lines_count: int) -> str:
        log_path = Path(LOG_FILE)
        if not log_path.exists():
            return 'Log file is empty.'

        try:
            lines = log_path.read_text(encoding='utf-8', errors='replace').splitlines()
        except OSError as exc:
            return f'Failed to read log file: {exc}'
        tail = lines[-lines_count:]
        if not tail:
            return 'Log file is empty.'

        text = '\n'.join(tail)
        if len(text) > 3800:
            text = f'...\n{text[-3800:]}'
        return text
